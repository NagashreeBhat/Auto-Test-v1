package com.PushNotifications;

public class ForegroundService extends com.worklight.androidgap.WLForegroundService{
	//Nothing to do here...
}