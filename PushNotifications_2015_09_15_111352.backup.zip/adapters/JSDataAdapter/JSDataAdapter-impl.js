function getSecretData(){
	return {
		secretData:123456
	}
}